INSERT INTO tootajas (eesnimi, perenimi, tel_nr, email, aadress)  VALUES
('Anna', 'M�gi', '555123456', 'anna@example.com', 'Kooli 5, Tallinn'),
('Marko', 'Kask', '555987654', 'marko@example.com', 'Pargi 3, Tartu'),
('Liis', 'Lill', '555234567', 'liis@example.com', 'J�e 10, P�rnu'),
('Jaan', 'K�la', '555345678', 'jaan@example.com', 'Mere 2, Narva'),
('Eva', 'P�ike', '555456789', 'eva@example.com', 'Linna 4, J�hvi'),
('Kati', 'Roos', '555567890', 'kati@example.com', 'Aia 1, Viljandi'),
('Mati', 'Raja', '555678901', 'mati@example.com', 'K�gu 6, Kuressaare'),
('Signe', 'Muru', '555789012', 'signe@example.com', 'Taeva 8, Rakvere'),
('Peeter', 'Puu', '555890123', 'peeter@example.com', 'Metsa 7, Haapsalu'),
('Kristi', 'Rohuneeme', '555901234', 'kristi@example.com', 'Ranna 9, V�ru');

insert into pussikliendid values
('tanno', 'M�gi', '555123456', 'tanno@example.com', 'Kooli 5, Tallinn'),
('illar', 'Kask', '555977654', 'illar@example.com', 'Pargi 13, Tartu'),
('Liis', 'Lill', '555234567', 'liis@example.com', 'J�e 25, P�rnu'),
('Jaan', 'K�la', '555345678', 'jaan@example.com', 'Mere 2, Narva'),
('Eva', 'P�ike', '555676789', 'eva@example.com', 'Linna 4, J�hvi'),
('Kati', 'Roos', '555567890', 'kati@example.com', 'Aia 1, Viljandi'),
('Mati', 'Raja', '555678901', 'mati@example.com', 'K�gu 6, Kuressaare'),
('Signe', 'Muru', '555789012', 'signe@example.com', 'Taeva 8, Rakvere'),
('Peeter', 'Puu', '555390123', 'peeter@example.com', 'Metsa 7, Haapsalu'),
('Kristi', 'Rohuneeme', '555901234', 'kristi@example.com', 'Ranna 7, V�ru');


